<script setup>
  import axios from 'axios';
  import {ref, onMounted, defineEmits } from "vue";
  import Question from "./shared/Question.vue";

  const emit = defineEmits(['handleAnswers']);

  const survey = ref(null);
  const loading = ref(true);
  const error = ref(null);
  const currentQuestionIndex = ref(0);

  const prevQuestion = () => {
      if (currentQuestionIndex.value > 0) {
          currentQuestionIndex.value--;
      }
  };

  const nextQuestion = () => {
      if (currentQuestionIndex.value < (survey.value?.questions.length || 0) - 1) {
          currentQuestionIndex.value++;
      }
  };

  const handleSelectOption = (question) => {
      // id starts from 1, for index, we would subtract 1.
      console.log(question);

      // Create a new reference for the questions and options array to trigger reactivity
      const updatedQuestions = [...survey.value.questions];
      const updatedOptions = [...updatedQuestions[question.question_id - 1].options];

      // Update the nested property
      updatedOptions.map((option) => {
         if(option.id === question.selected_option_id) {
             option.isChecked = true;
         }
      });

      // Reassign the updated options back to the question
      updatedQuestions[question.question_id - 1] = {
          ...updatedQuestions[question.question_id - 1],
          options: updatedOptions
      };

      // Reassign the updated questions array back to the survey
      survey.value = {
          ...survey.value,
          questions: updatedQuestions
      };
  };

  const handleCannotAnswer = (question_id) => {
      console.log("Cannot answer question num: " + question_id);
  };

  const handleSubmit = () => {
      emit('handleAnswers', survey.value);
  }

  onMounted(() => {
    setTimeout(async () => {
        try {
            // const response = await axios.get('http://localhost:8000/survey/1');
            //
            // survey.value = response.data;
        } catch (err) {
            error.value = 'Failed to fetch the survey. Please try again later.'
        } finally {
            loading.value = false;

            survey.value = {
                "id": 1,
                "title": "Digital Services Maturity Indicator",
                "description": "A survey to measure the maturity of digital services within an organization.",
                "created_at": "2024-09-14T11:36:03.000000Z",
                "updated_at": "2024-09-14T11:36:03.000000Z",
                "questions": [
                    {
                        "id": 1,
                        "survey_id": 1,
                        "question_type": "mcq",
                        "question_text": "How would you describe your organization's automation strategy?",
                        "image_path": "https://images.nightcafe.studio/jobs/YXxaIKGr4FKsuJbi2adY/YXxaIKGr4FKsuJbi2adY--1--mis2e_6x.jpg?tr=w-1600,c-at_max",
                        "image_alignment": "right",
                        "created_at": "2024-09-14T11:36:24.000000Z",
                        "updated_at": "2024-09-14T11:36:24.000000Z",
                        "options": [
                            {
                                "id": 1,
                                "question_id": 1,
                                "option_text": "Non-existent",
                                "created_at": "2024-09-14T11:36:45.000000Z",
                                "updated_at": "2024-09-14T11:36:45.000000Z"
                            },
                            {
                                "id": 2,
                                "question_id": 1,
                                "option_text": "Ad-hoc",
                                "created_at": "2024-09-14T11:36:45.000000Z",
                                "updated_at": "2024-09-14T11:36:45.000000Z"
                            },
                            {
                                "id": 3,
                                "question_id": 1,
                                "option_text": "Defined but not documented",
                                "created_at": "2024-09-14T11:36:45.000000Z",
                                "updated_at": "2024-09-14T11:36:45.000000Z"
                            },
                            {
                                "id": 4,
                                "question_id": 1,
                                "option_text": "Documented but not widely communicated",
                                "created_at": "2024-09-14T11:36:45.000000Z",
                                "updated_at": "2024-09-14T11:36:45.000000Z"
                            },
                            {
                                "id": 5,
                                "question_id": 1,
                                "option_text": "Clearly documented and communicated throughout the organization",
                                "created_at": "2024-09-14T11:36:45.000000Z",
                                "updated_at": "2024-09-14T11:36:45.000000Z"
                            }
                        ]
                    },
                    {
                        "id": 2,
                        "survey_id": 1,
                        "question_type": "mcq",
                        "question_text": "Is there executive support and sponsorship for automation initiatives?",
                        "image_path": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmiIvy-4J8_B7sYJ2ukF9vkc2wo6vXdbss2EKn9YuOoif0DuYXzDRsx4U559aG360S9f0&usqp=CAU",
                        "image_alignment": "left",
                        "created_at": "2024-09-14T11:36:24.000000Z",
                        "updated_at": "2024-09-14T11:36:24.000000Z",
                        "options": [
                            {
                                "id": 6,
                                "question_id": 2,
                                "option_text": "No awareness",
                                "created_at": "2024-09-14T11:36:45.000000Z",
                                "updated_at": "2024-09-14T11:36:45.000000Z"
                            },
                            {
                                "id": 7,
                                "question_id": 2,
                                "option_text": "Awareness but no formal support",
                                "created_at": "2024-09-14T11:36:45.000000Z",
                                "updated_at": "2024-09-14T11:36:45.000000Z"
                            },
                            {
                                "id": 8,
                                "question_id": 2,
                                "option_text": "Limited support for specific projects",
                                "created_at": "2024-09-14T11:36:45.000000Z",
                                "updated_at": "2024-09-14T11:36:45.000000Z"
                            },
                            {
                                "id": 9,
                                "question_id": 2,
                                "option_text": "Strong support for some business areas",
                                "created_at": "2024-09-14T11:36:45.000000Z",
                                "updated_at": "2024-09-14T11:36:45.000000Z"
                            },
                            {
                                "id": 10,
                                "question_id": 2,
                                "option_text": "Full executive sponsorship and ongoing support",
                                "created_at": "2024-09-14T11:36:45.000000Z",
                                "updated_at": "2024-09-14T11:36:45.000000Z"
                            }
                        ]
                    },
                    {
                        "id": 3,
                        "survey_id": 1,
                        "question_type": "mcq",
                        "question_text": "What technologies are currently in place for automation?",
                        "image_path": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6mSUMa8u-9XcSVK4JKlTZi_0wu43MAn7ayw&s",
                        "image_alignment": "right",
                        "created_at": "2024-09-14T11:36:24.000000Z",
                        "updated_at": "2024-09-14T11:36:24.000000Z",
                        "options": [
                            {
                                "id": 11,
                                "question_id": 3,
                                "option_text": "No specific technologies",
                                "created_at": "2024-09-14T11:36:45.000000Z",
                                "updated_at": "2024-09-14T11:36:45.000000Z"
                            },
                            {
                                "id": 12,
                                "question_id": 3,
                                "option_text": "Basic scripting and macros",
                                "created_at": "2024-09-14T11:36:45.000000Z",
                                "updated_at": "2024-09-14T11:36:45.000000Z"
                            },
                            {
                                "id": 13,
                                "question_id": 3,
                                "option_text": "Some isolated RPA implementations",
                                "created_at": "2024-09-14T11:36:45.000000Z",
                                "updated_at": "2024-09-14T11:36:45.000000Z"
                            },
                            {
                                "id": 14,
                                "question_id": 3,
                                "option_text": "Multiple RPA technologies, but not integrated",
                                "created_at": "2024-09-14T11:36:45.000000Z",
                                "updated_at": "2024-09-14T11:36:45.000000Z"
                            },
                            {
                                "id": 15,
                                "question_id": 3,
                                "option_text": "Fully integrated RPA, AI, and other automation technologies",
                                "created_at": "2024-09-14T11:36:45.000000Z",
                                "updated_at": "2024-09-14T11:36:45.000000Z"
                            }
                        ]
                    }
                ]
            }

            console.log(survey);
        }
    }, 1000);
  });
</script>

<template>
  <section class="survey-questions-container">
      <!-- Loading State -->
      <div v-if="loading" class="loading-msg">
          Loading Survey...
      </div>

      <!-- Error State -->
      <div v-if="error" class="error-msg">
          {{ error }}
      </div>

      <!-- Survey Data -->
      <div v-if="survey" style="width: 100%">
          <div v-if="survey.questions.length > 0">
              <!-- Question Navigation Controls - Left -->
              <span class="previous-question"
                  @click="prevQuestion"
                  :hidden="currentQuestionIndex === 0"
              >
                  <i class="fa-solid fa-chevron-left"></i>
                  Previous Question
              </span>

              <!-- Display Current Question -->
              <Question
                      :question="survey.questions[currentQuestionIndex]"
                      :question_number="currentQuestionIndex + 1"
                      :questions_length="survey.questions.length"
                      @handleNextQuestionClick="nextQuestion"
                      @handleOptionSelect="handleSelectOption"
                      @handleCannotAnswerClick="handleCannotAnswer"
                      @handleSubmitAnswers="handleSubmit"
              />
          </div>
      </div>
  </section>
</template>

<style scoped>
  .survey-questions-container {
      padding: 10px 8%;
      margin: 25px 0;
  }

  .error-msg {
      color: red;
      letter-spacing: 0.3px;
      font-size: 18px;
  }

  .loading-msg {
      color: green;
      letter-spacing: 0.3px;
      font-size: 18px;
  }

  .previous-question {
      font-size: small;
      letter-spacing: 0.3px;
      color: gray;
      cursor: pointer;
  }

  .previous-question:hover {
      color: black;
  }

  @media screen and (max-width: 768px) {
      .survey-questions-container {
          padding: 10px 1%;
      }
  }
</style>

