<script setup>
import {defineProps, defineEmits, onMounted} from "vue";
  import CustomOption from "./CustomOption.vue";

  const props = defineProps({
      question: {
          type: Object,
          required: true
      },
      question_number: {
          type: Number,
          required: true
      },
      questions_length: {
          type: Number,
          required: true,
      }
  });

  const emit = defineEmits(['handleNextQuestionClick', 'handleOptionSelect', 'handleCannotAnswerClick', 'handleSubmitAnswers']);

  const handleNextQuestionClick = () => {
      emit('handleNextQuestionClick');
  }

  const handleSelectOption = (id) => {
      props.question.options.map((opt) => {
          opt.isChecked = false;
      });

      try {
          emit('handleOptionSelect', { question_id: props.question.id, selected_option_id: id });
      } catch (error) {
          console.log(error);
      }
  }

  const handleCannotAnswerClick = () => {
      emit('handleCannotAnswerClick', props.question.id)
  }

  const handleSubmitAnswers = () => {
      emit('handleSubmitAnswers');
  }
</script>

<template>
    <div class="question-container" :class="{'image-left': props.question.image_alignment === 'left', 'image-right': props.question.image_alignment === 'right'}">
        <div class="question-text-container">
            <!-- Question number -->
            <div class="question-number-container">
                <h1 class="question-number">
                    Question {{ question_number }}/{{ questions_length }}
                </h1>
            </div>

            <h2 class="question-text">{{ props.question.question_text }}</h2>

            <!-- Options for each question -->
            <ul>
                <li v-for="option in props.question.options" :key="option.id">
                    <CustomOption
                            :option="option"
                            @handleSelectedOption="handleSelectOption"
                    />
                </li>

                <span class="cannot-answer" @click="handleCannotAnswerClick">
                    I can’t answer this question, as it isn’t relevant to my area of business
                </span>
            </ul>

            <!-- Question Navigation Controls - Right -->
            <button class="next-question"
                    @click="handleNextQuestionClick"
                    :class="{'hidden': question_number >= questions_length}"
            >
                <span>Next Question</span>
                <i class="fa-solid fa-chevron-right"></i>
            </button>

            <button class="submit-answers hidden"
                    @click="handleSubmitAnswers"
                    :class="{'visible': question_number >= questions_length}"
            >
                <span>Submit</span>
                <i class="fa-solid fa-chevron-right"></i>
            </button>
        </div>

        <div class="question-image-container">
            <img
                    v-if="props.question.image_path"
                    :src="props.question.image_path"
                    class="question-img"
                    alt="Question Image"
            />
        </div>

    </div>
</template>

<style scoped>
  .question-container {
      display: flex;
      gap: 50px;
      padding-top: 10px;
  }

  .image-left {
      flex-direction: row-reverse;
  }

  .question-number {
      text-transform: uppercase;
      color: limegreen;
  }

  .question-text-container{
      flex: 1;
  }

  .question-image-container {
      flex: 0.8;
  }

  .next-question, .submit-answers {
      border: none;
      background: linear-gradient(90deg, limegreen, darkgreen);
      padding: 15px 20px;
      color: white;
      font-size: 18px;
      border-radius: 50px;
      cursor: pointer;
      font-weight: bold;
      letter-spacing: 0.3px;

      display: flex;
      align-items: center;
      gap: 15px;
  }

  .question-img {
      width: 100%;
      border-radius: 15px;
      box-shadow: 0 0 5px 0 gray;
  }

  ul {
      padding: 5px 0 25px 0;
      list-style-type: none;
  }

  li {
      margin: 18px 0;
  }

  .cannot-answer {
      text-decoration: underline;
      letter-spacing: 0.3px;
      cursor: pointer;
  }

  .hidden {
      display: none;
  }

  .visible {
      display: flex;
      background: linear-gradient(90deg, darkgreen, limegreen);
  }
</style>