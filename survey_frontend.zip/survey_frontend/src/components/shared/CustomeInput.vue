<script setup>
import { defineProps, ref, defineEmits } from 'vue';

const props = defineProps({
    label: {
        type: String,
        required: true,
    },
    type: {
        type: String,
        required: true,
    },
    input_for: {
        type: String,
        required: true,
    }
});

const emit = defineEmits(['handleValueChange']);

// Track if input is focused or has content
const isFocused = ref(false);
const inputValue = ref('');
const inputRef = ref(null);

const handleFocus = () => {
    isFocused.value = true;
    if (inputRef.value) {
        inputRef.value.focus();
    }
};

const handleBlur = () => {
    // Only set isFocused to false if inputValue is empty
    if (inputValue.value.trim() === '') {
        isFocused.value = false;
    } else {
        emit('handleValueChange', { name: props.input_for, value: inputValue});
    }
};

</script>

<template>
    <div class="form-group">
        <!-- Label moves up if input is focused or has value -->
        <label :class="{'label-to-top': isFocused || inputValue }" @click="handleFocus">{{ label }}</label>
        <input
            :type="type"
            :name="input_for"
            v-model="inputValue"
            @focus="handleFocus"
            @blur="handleBlur"
            ref="inputRef"
        >
    </div>
</template>

<style scoped>
.form-group {
    margin: 8px 0;
    position: relative;
    width: 100%;
    display: flex;
    align-items: center;
}

label {
    position: absolute;
    margin-left: 20px;
    letter-spacing: 0.35px;
    cursor: text;
    transition: 0.2s ease all; /* Add a smooth transition */
}

.label-to-top {
    margin: 0 10px;
    top: 2px;
    font-size: small;
    color: gray;
}

input {
    width: 100%;
    background-color: #f3f1f1;
    border: none;
    outline: none;
    padding: 15px 20px;
    border-radius: 10px;
    font-size: 16px;
}
</style>
