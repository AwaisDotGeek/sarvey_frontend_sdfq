<script setup>
import {computed, onMounted, ref, watch} from 'vue';

  const props = defineProps({
      value: {
          type: Number,
          required: true,
          default: 0,
          validator: (val) => val >= 0 && val <= 100
      },
      needleColor: {
          type: String,
          default: 'black',
      },
      gradientColor: {
          type: String,
          default: '',
      },
      maskColor: {
          type: String,
          default: 'white',
      }
  });

  // Computed properties to calculate needle position
  const angle = computed(() => {
      // Calculate the angle between 0 to 180 degrees
      return (props.value / 100) * 180;
  });

  // Convert angle to degrees for CSS transform
  const needleAngle = computed(() => angle.value - 90);

  // Define gradients for different colors
  const gradients = {
      green: ['lightgreen', 'seagreen', 'darkgreen'],
      blue: ['lightblue', 'royalblue', 'darkblue'],
      purple: ['lavender', 'mediumorchid', 'purple'],
      orange: ['lightsalmon', 'orange', 'orangered'],
      pink: ['lightpink', 'hotpink', 'deeppink']
  };

  // Compute gradient colors based on the prop
  const gradientColors = computed(() => {
      const baseColor = props.gradientColor.toLowerCase();
      return gradients[baseColor];
  });

  const gradientStyle = ref({});
  onMounted(() => {
      const gradient = `linear-gradient(to right, ${gradientColors.value[0]}, ${gradientColors.value[1]}, ${gradientColors.value[2]})`;
      gradientStyle.value = { background: gradient }
  });

</script>

<template>
  <div class="meter-container">
      <div class="meter" :style="gradientStyle">
          <div class="mask" :style="{ 'background': maskColor}">
              <div class="needle" :style="{ 'background': needleColor, transform: `rotate(${needleAngle}deg)` }"></div>
              <div class="needle-circle" :style="{ 'background': needleColor }"></div>
          </div>
      </div>
      <div style="position: absolute; bottom: -15px;">
          <div style="width: 300px; display: flex; justify-content: space-between; font-weight: bold">
              <span style="width: 50px; text-align: center">0</span>
              <span style="width: 50px; text-align: center">100</span>
          </div>
      </div>
  </div>
</template>

<style scoped>
  .meter-container {
      position: relative;
      display: flex;
      justify-content: center;
      height: 160px;
      /*width: 200px;*/
      width: 100%;
  }
  .meter {
      /*width: 180px;*/
      /*height: 180px;*/
      width: 300px;
      height: 300px;
      border-radius: 100% 100% 0 0;
      clip-path: polygon(0% 0%, 100% 0%, 100% 50%, 0% 50%);
      position: absolute;
  }

  .mask {
      position: absolute;
      background-color: #fff;
      /*width: 120px;*/
      /*height: 120px;*/
      width: 200px;
      height: 200px;
      border-radius: 100% 100% 0 0;
      margin: calc(50% - 100px) calc(50% - 100px);
      clip-path: polygon(0% 0%, 100% 0%, 100% 50%, 0% 50%);
  }

  .needle {
      height: 90px;
      z-index: 999;
      width: 15px;
      position: absolute;
      left: calc(50% - 7.5px);
      bottom: calc(50%);
      clip-path: polygon(50% 0, 50% 0, 100% 100%, 0 100%);
      transform-origin: bottom center;
      transition: transform 0.5s ease;
  }

  .needle-circle {
      width: 25px;
      height: 25px;
      border-radius: 100%;
      position: absolute;
      margin: calc(50% - 12.5px);
  }
</style>