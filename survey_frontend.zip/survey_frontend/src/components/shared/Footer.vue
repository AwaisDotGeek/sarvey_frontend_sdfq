<template>
  <footer>
      <p>
          © Copyright 2023 Ricoh UK. All rights reserved
      </p>
  </footer>
</template>

<style scoped>
  footer {
      padding: 25px 8%;
      border-top: 2px solid green;
      margin-top: 65px;
  }

  @media screen and (max-width: 768px) {
      padding: 25px 1%;
  }
</style>