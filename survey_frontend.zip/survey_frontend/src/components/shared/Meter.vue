<script setup>
  import {computed, onMounted, ref} from 'vue';

  // Prop to receive the speedometer value (0 to 100)
  const props = defineProps({
      value: {
          type: Number,
          required: true,
          default: 0,
          validator: (val) => val >= 0 && val <= 100
      },
      needleColor: {
          type: String,
          default: 'white',
      },
      gradientColor: {
          type: String,
          default: '',
      }
  });

  const gradients = {
      green: ['#98fb30', '#32cd30', '#006400'], // Light green to dark green
      blue: ['#add8e6', '#4682b4', '#00008b'], // Light blue to dark blue
      purple: ['#d8a2d6', '#a75fa3', '#4b0082'], // Light purple to dark purple
      orange: ['#f5b041', '#f39c12', '#e67e22'], // Light orange to dark orange
      pink: ['#f9c2c2', '#f58a8a', '#d63384'], // Light pink to dark pink
  };

  // Compute gradient colors based on the prop
  const gradientColors = computed(() => {
        const baseColor = props.gradientColor.toLowerCase();
        console.log(gradients[baseColor] + " " + gradients[baseColor][0]);
        return gradients[baseColor];
  });


  // Computed properties to calculate needle position
  const angle = computed(() => {
      // Calculate the angle between 0 to 180 degrees
      return (props.value / 100) * 180;
  });

  // Convert angle to radians for trigonometric calculations
  const radians = computed(() => {
      return (angle.value - -180) * (Math.PI / 180); // Adjusting by -90 to start from the bottom
  });

  // Calculate needle end coordinates
  const needleLength = 150; // Increase length for the larger size
  const needleX = computed(() => {
      return 200 + needleLength * Math.cos(radians.value); // Adjust based on the larger SVG size
  });
  const needleY = computed(() => {
      return 200 + needleLength * Math.sin(radians.value); // Adjust based on the larger SVG size
  });
</script>

<template>
    <div class="speedometer">
        <svg viewBox="0 0 400 220" class="speedometer-svg"> <!-- Increased height for text -->
            <!-- Background of the meter with gradient colors -->
            <defs>
                <linearGradient id="meterGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" :style="{stopColor: gradientColors[0], stopOpacity: 1}" /> <!-- Light green -->
                    <stop offset="50%" :style="{stopColor: gradientColors[1], stopOpacity: 1}" /> <!-- Medium green -->
                    <stop offset="100%" :style="{stopColor: gradientColors[2], stopOpacity: 1}" /> <!-- Dark green -->
                </linearGradient>
            </defs>

            <!-- Draw the arc using a path with the gradient -->
            <path
                    d="M 20 200 A 180 180 0 0 1 380 200"
                    stroke="url(#meterGradient)"
                    stroke-width="40"
                    fill="none"
            />

            <!-- Speedometer needle (pointy with a round base) -->
            <!-- Round base of the needle -->
            <circle cx="200" cy="200" r="15" :fill="needleColor" />

            <!-- Pointy needle -->
            <polygon
                    :points="`190,200 210,200 ${needleX},${needleY}`"
                    :fill="needleColor"
            />

            <!-- Labels -->
            <!-- Label 0 at the start of the arc -->
            <text x="20" y="220" font-size="16" :fill="needleColor" text-anchor="middle">0</text>
            <!-- Label 100 at the end of the arc -->
            <text x="380" y="220" font-size="16" :fill="needleColor" text-anchor="middle">100</text>
        </svg>
    </div>
</template>

<style scoped>
  .speedometer {
      width: 400px; /* Increase the width */
      height: 200px; /* Increase the height */
      display: flex;
      justify-content: center;
      align-items: center;
  }

  .speedometer-svg {
      width: 100%;
      height: 100%;
  }
</style>
