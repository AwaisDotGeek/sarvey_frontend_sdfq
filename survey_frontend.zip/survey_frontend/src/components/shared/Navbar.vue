<template>
  <nav>
      <!-- Logo -->
      <div class="survey-logo-container" style="display: flex">
          <img
                  src="https://th.bing.com/th/id/OIP.e8HdrwittnX6IdjmhWLfOwHaHa?rs=1&pid=ImgDetMain"
                  alt="Logo"
                  class="survey-logo"
          />
      </div>
  </nav>
</template>

<style scoped>
  nav {
      padding: 10px 8%;
  }
  .survey-logo-container {
      display: flex;
  }
  .survey-logo {
      max-height: 65px;
      object-fit: cover;
  }

  @media screen and (max-width: 768px) {
      nav {
          padding: 10px 1%;
      }
  }
</style>