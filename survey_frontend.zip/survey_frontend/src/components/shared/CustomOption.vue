<script setup>
  import { defineProps, ref, defineEmits, watch } from 'vue';

  const props = defineProps({
      option: {
          type: Object,
          required: true,
      }
  });

  const isChecked = ref(props.option.isChecked);

  const emit = defineEmits(['handleSelectedOption']);

  const handleCheckClick = () => {
      emit('handleSelectedOption', props.option.id);
  }

  watch(() => props.option.isChecked, (newVal) => {
      isChecked.value = newVal;
  });
</script>

<template>
  <div class="option-container">
      <span
              class="option-check"
              :class="{'checked-outer': isChecked}"
              @click="handleCheckClick"
      >
          <span :hidden="!isChecked" class="checked-inner"></span>
      </span>
      <span class="option-text">
        {{ option.option_text }}
      </span>
  </div>
</template>

<style scoped>
  .option-container {
      display: flex;
      gap: 15px;
  }
  .option-check {
      width: 16px;
      height: 16px;
      border: 1px solid black;
      border-radius: 100%;
      cursor: pointer;

      display: flex;
      justify-content: center;
      align-items: center;
  }
  .checked-outer {
      border: 1px solid green !important;
  }
  .checked-inner {
      width: 75%;
      height: 75%;
      background-color: green;
      border-radius: 100%;
  }
  .option-text {
      letter-spacing: 0.35px;
      flex: 1;
  }
</style>