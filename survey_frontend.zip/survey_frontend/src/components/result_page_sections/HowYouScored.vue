<template>
  <!-- How You Scored -->
    <section class="how-you-scored">
        <h1>How you scored</h1>
        <p>
            Your results demonstrate how you can improve organisational digital maturity and start leading
            change at work today.
            Below is an overview of your results. A personalised report will be in your
            inbox shortly.
        </p>
    </section>
</template>

<style scoped>
  .how-you-scored {
      width: 55%;
      margin: 65px 0;
      padding: 10px 8%;
  }

  .how-you-scored > h1 {
      font-weight: bold;
      font-family: Serif;
      font-size: 48px;
      margin: 0;
  }

  .how-you-scored > p {
      letter-spacing: 0.1px;
      color: #2e3136;
      line-height: 22px;
      color: #4a5568;
  }

  @media screen and (max-width: 768px) {
      .how-you-scored {
          width: 85%;
          padding: 0 1%;
      }
  }
</style>