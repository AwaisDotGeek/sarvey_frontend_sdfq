<script setup>
 import Meter from "../shared/Meter.vue";
 import TestMeter from "../shared/TestMeter.vue";
</script>

<template>
    <section class="your-overall-score">
        <div class="your-overall-score-meter">
            <TestMeter value=55 gradientColor="green" maskColor="#222222" needleColor="white" />
        </div>

        <div class="your-overall-score-right-text-container">
            <h1>
                Your Overall Score
            </h1>
            <div>
                <h2>
                    Inconclusive
                </h2>
                <p>
                    We could use some more information to generate an accurate Digital Services Maturity
                    Score.
                    Get in touch with one of our Digital Experts who can help or take the survey again.
                </p>
            </div>
        </div>
    </section>
</template>

<style scoped>
  .your-overall-score {
      background-color: #222222;
      padding: 65px 8%;
      color: #fff;
      display: flex;
      align-items: center;
  }

  .your-overall-score-meter {
      flex: 1;
  }

  .your-overall-score-right-text-container {
      flex: 1.1;
  }

  .your-overall-score-right-text-container > h1 {
      font-family: Serif;
      font-size: 36px;
      font-weight: bold;
      margin-bottom: 35px;
  }

  .your-overall-score-right-text-container > div > h2 {
      padding-bottom: 1px;
      border-bottom: 1.5px solid #fff;
      letter-spacing: 0.3px;
      width: fit-content;
  }

  .your-overall-score-right-text-container > div > p {
      letter-spacing: 0.1px;
      font-size: 16px;
      line-height: 22px;
  }

  @media screen and (max-width: 768px) {

      .your-overall-score {
          flex-direction: column;
          align-items: center;
      }

      .your-overall-score-right-text-container {
          padding: 10px 5%;
      }
  }
</style>