<script setup>
    import Meter from "../shared/Meter.vue";
    import TestMeter from "../shared/TestMeter.vue";
    import { defineProps } from 'vue';

    const props = defineProps({
        meter_value: {
            type: Number,
            required: true,
        },
        meter_gradientColor: {
            type: String,
            required: true,
        },
        title: {
            type: String,
            required: true,
        },
        text1: {
            type: String,
            required: true,
        },
        text2: {
            type: String,
        },
        text3: {
            type: String,
        }
    });
</script>

<template>
  <div class="card">
      <div>
          <TestMeter :value=meter_value needleColor="black" :gradientColor="meter_gradientColor" />
      </div>
      <div class="info-container">
          <h3>{{ title }}</h3>
          <p>
              {{ text1 }}
          </p>
          <p>
              {{ text2 }}
          </p>
          <p>
              {{ text3 }}
          </p>
      </div>
  </div>
</template>

<style scoped>
  .card {
      background-color: #fff;
      width: fit-content;
      max-width: 300px;
      padding: 10px 35px;
      border-radius: 15px;
      box-shadow: 0 2px 5px 0 dimgray;
  }

  .info-container > h3 {
      letter-spacing: 0.3px;
      margin-top: 40px;
      font-size: 22px;
  }

</style>