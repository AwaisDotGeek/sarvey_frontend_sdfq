<script setup>
    import CustomeInput from "./shared/CustomeInput.vue";
    import { ref, defineEmits } from "vue";

    const form = ref({});

    const emit = defineEmits(['handleFormSubmit']);

    const handleFormUpdate = (params) => {
        form.value[params.name] = params.value;
    }

    const handleFormSubmit = (e) => {
        e.preventDefault();

        // conditions for data here

        // send form data to parent
        emit('handleFormSubmit', form.value);
    }
</script>

<template>
  <section>
      <div class="text-container">
          <h2>
              Thanks for completing the Digital Services
              Maturity Indicator
          </h2>

          <div>
              <h3>
                  Access your full personalised results now to receive:
              </h3>
              <ul>
                  <li>
                      Your overall Digital Services Maturity Score
                  </li>
                  <li>
                      Your five individual scores related to the critical elements of your workplace
                  </li>
                  <li>
                      An outline of how you can improve your organisations digital maturity
                  </li>
                  <li>
                      The opportunity to access further personalised consultancy with our Digital
                      Experts
                  </li>
              </ul>
          </div>

          <h4>
              Simply complete your details to access your full personalised results now
          </h4>
      </div>
      <div class="registration-container">
          <h2>Access your Personalised Results</h2>
          <form @submit="handleFormSubmit">
              <CustomeInput label="First Name" type="text" input_for="first_name" @handleValueChange="handleFormUpdate" />
              <CustomeInput label="Last Name" type="text" input_for="last_name" @handleValueChange="handleFormUpdate" />
              <CustomeInput label="Email Address" type="email" input_for="email" @handleValueChange="handleFormUpdate" />
              <CustomeInput label="Company Name" type="text" input_for="company_name" @handleValueChange="handleFormUpdate" />
              <CustomeInput label="Executive" type="text" input_for="executive" @handleValueChange="handleFormUpdate" />
              <CustomeInput label="Phone Number" type="text" input_for="phone_number" @handleValueChange="handleFormUpdate" />

              <p style="text-align: center; font-size: small; font-weight: bold">
                  By clicking on Submit, you agree to our
                  <span style="color: green;">
                      Privacy Policy
                  </span>
              </p>
              <div class="form-end-note-container">
                  <i class="fa-solid fa-info" style="color: green; font-size: 10px; border: 1px solid green; width: 12px; height: 12px; border-radius: 100%; text-align: center; padding: 2px;"></i>
                  <p>
                      Ad blockers can interfere with this form. Please deactivate any active
                      <br />
                      ad blocker before submission. Click here for mrore information
                  </p>
              </div>
              <button class="submit-button">
                  Submit
              </button>
          </form>
      </div>
  </section>
</template>

<style scoped>
  section {
      padding: 70px 8%;
      display: flex;
      gap: 35px;
  }

  .text-container {
      flex: 1.3;
      padding: 70px 70px 70px 0;
  }

  .text-container > div {
      padding: 25px 0;
      border-top: 1px solid green;
  }

  .text-container > div > ul {
      padding: 0 0 0 25px;
      display: flex;
      flex-direction: column;
      gap: 15px;
  }

  .registration-container {
      padding: 20px 50px;
      margin: 20px;
      background: white;
      border-radius: 20px;
      box-shadow: 1px 4px 8px 0 lightgrey;
      flex: 1;
  }

  .registration-container > h2 {
      text-align: center;
      color: green;
  }

  h2, h3 {
      letter-spacing: 0.3px;
  }

  form {
      display: flex;
      flex-direction: column;
      align-items: center;
  }

  .form-end-note-container {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: small;
  }

  .submit-button {
      background: linear-gradient(90deg, limegreen, green);
      border: none;
      padding: 15px 50px;
      font-size: 16px;
      letter-spacing: 0.3px;
      color: white;
      width: 100%;
      border-radius: 5px;
      margin-top: 10px;
      cursor: pointer;
  }
</style>