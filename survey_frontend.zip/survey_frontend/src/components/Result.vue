<script setup>
import Meter from "./shared/Meter.vue";
import HowYouScored from "./result_page_sections/HowYouScored.vue";
import YourOverAllScore from "./result_page_sections/YourOverAllScore.vue";
import MeterCard from "./result_page_sections/MeterCard.vue";
import TestMeter from "./shared/TestMeter.vue";
</script>

<template>
    <main>
        <HowYouScored />
        <YourOverAllScore />

        <section class="meter-cards">
            <div class="meter-cards-container">
                <MeterCard
                    meter_value="25"
                    meter_gradientColor="blue"
                    title="Digital Workplace"
                    text1="We could use some more information to generate an accurate Digital Workplace Maturity Score."
                    text2="This will help you to understand where your digital workspace technology may be limiting your hybrid work practices and people."
                    text3="Need help? Speak to our digital experts"
                />
                <MeterCard
                    meter_value="45"
                    meter_gradientColor="purple"
                    title="Digital Experience"
                    text1="We could use some more information to generate an accurate Digital Workplace Maturity Score."
                    text2="This will help you to understand where your digital workspace technology may be limiting your hybrid work practices and people."
                    text3="Need help? Speak to our digital experts"
                />
                <MeterCard
                    meter_value="65"
                    meter_gradientColor="orange"
                    title="Business Process"
                    text1="We could use some more information to generate an accurate Digital Workplace Maturity Score."
                    text2="This will help you to understand where your digital workspace technology may be limiting your hybrid work practices and people."
                    text3="Need help? Speak to our digital experts"
                />
                <MeterCard
                    meter_value="75"
                    meter_gradientColor="pink"
                    title="Cloud & Infrastructure"
                    text1="We could use some more information to generate an accurate Digital Workplace Maturity Score."
                    text2="This will help you to understand where your digital workspace technology may be limiting your hybrid work practices and people."
                    text3="Need help? Speak to our digital experts"
                />
                <MeterCard
                    meter_value="80"
                    meter_gradientColor="green"
                    title="Cybersecurity"
                    text1="We could use some more information to generate an accurate Digital Workplace Maturity Score."
                    text2="This will help you to understand where your digital workspace technology may be limiting your hybrid work practices and people."
                    text3="Need help? Speak to our digital experts"
                />
            </div>
        </section>
    </main>
</template>

<style scoped>

    .meter-cards {
        padding: 50px 8%;
    }

    .meter-cards-container {
        display: flex;
        justify-content: center;
        align-items: center;
        flex-wrap: wrap;
        gap: 25px;
    }

</style>