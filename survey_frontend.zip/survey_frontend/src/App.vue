<script setup>
  import Navbar from "./components/shared/Navbar.vue";
  import Questions from "./components/Questions.vue";
  import Footer from "./components/shared/Footer.vue";
  import Register from "./components/Register.vue";
  import {ref} from 'vue';
  import Result from "./components/Result.vue";

  const questionsAnswered = ref(false);
  const formFilled = ref(false);

  const handleAnswers = (survey) => {
      console.log("User Submits the following. Note that the ids corresponds Database ids");
      console.log(survey);
      survey.questions.map((question) => {
          console.log("Question id => " + question.id);
          question.options.map((option) => {
             if(option.isChecked && option.isChecked) {
                 console.log("Selected option id => " + option.id);
             }
          });
      });

      questionsAnswered.value = true;
  }

  const handleFormData = (form) => {
      // submit form data here
      console.log(form);

      formFilled.value = true;
  }
</script>

<template>
  <div v-if="!questionsAnswered">
      <Navbar />
      <Questions @handleAnswers="handleAnswers" />
      <Footer />
  </div>

  <div v-if="questionsAnswered && !formFilled" class="reg-div">
      <Register @handleFormSubmit="handleFormData" />
  </div>

  <div v-if="formFilled">
      <Navbar />
      <Result />
      <Footer />
  </div>
</template>

<style scoped>
  .reg-div {
      background-image: url("https://img.freepik.com/free-vector/vector-white-gradient-background-modern-design_361591-4403.jpg?size=626&ext=jpg");
      background-repeat: no-repeat;
      background-position: center;
      background-size: cover;
  }
</style>
